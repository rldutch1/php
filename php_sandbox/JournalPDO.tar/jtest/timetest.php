<?php
include('../php1/includes/pw5pdo.php');
$h = '7';// Hour for time zone goes here e.g. +7 or -4, just remove the + or -
$hm = $h * 60;
$ms = $hm * 60;
$gmdate = gmdate('Y-m-d H:i:s', time()-($ms)); // the '-' can be switched to a plus if that's what your time zone is.
echo '<br />Your current time now is: ' . $gmdate . '.<br />' ;

echo "
<!DOCTYPE html>
<html>
	<head>
		<style type='text/css'>
		</style>
		<script type='text/javascript' src='javascript.js'></script>
	</head>
<body>
<form action='' method='POST'>
<input type='radio' name='posneg' value='neg'> -

<select name='offset'>";

foreach($handler->query('select * from timezones') as $row) {
	echo "<option value=" . $row['id'] . ">" . $row['offset'] . "</option>";
	}

echo "</select>

<input type='radio' name='posneg' value='pos'> +
<input type='submit' name='submit' value='" . $gmdate . "'>
</form>

</body>
</html>

";
?>