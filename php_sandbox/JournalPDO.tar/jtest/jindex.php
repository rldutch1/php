<?php
/*
session_start();
session_regenerate_id(true);
	if ($_SESSION['username'])
	{
*/
include_once('../php1/includes/pw5pdo.php');
include('jtest.php');

if (isset($_POST['entry'])){
$stmt->execute();
}

	echo "
	<html>
	<head>

	</head>
	<body>
	<style>
	body {
	background-color: c0c0c0;
	}
	table {
		border-style:solid;
		border-collapse:collapse;
		border-color:red;
		width: 99%;
		color: black;
		background-color: c0c0c0;

	}
	th, td
	{
		border: 1px solid black;
		border-style:solid;
		border-collapse:collapse;
		border-color:red;
		/*width: 100%;*/
	}
	.error
	{
		color: #FF0000;
	}
	</style>

	<a href='membersarea.php'>Members Area</a><br />
	<a href='logout.php'>Logout</a><br /><br />
<form action='jindex.php' method='POST'>
Entry: <br /><textarea type='text' autofocus='autofocus' maxlength='1000000' rows='2' cols='99%' wrap='hard' name='entry'></textarea>
	<!-- Entry: <input type='text' name='entry' size='50'> --><br />
	<input type='submit' name='submit' value='Submit'><br />
</form>

<div><table id='id2'><caption>Journal</caption><tr><td colspan='3'></td></tr>
<tr bgcolor='808080'><th>UTC</th><th>Current Time</th><th>Entry</th></tr>

	";

foreach($handler->query("select * from jtest") as $row) {
	echo '<tr><td>' . nl2br($row['utc_dttm']) . '</td><td>'
	 . nl2br($row['cur_dttm']) . '</td><td>'
	  . nl2br($row['entry']) . '</td></tr>';
}

		echo "</table></div></body></html>";

/*
}

else {
	header ("location: .");
}
*/
?>
