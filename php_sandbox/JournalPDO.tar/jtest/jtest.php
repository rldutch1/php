<?php
//http://php.net/manual/en/function.date-default-timezone-set.php
include_once('../php1/includes/pw5pdo.php');
date_default_timezone_set("utc");
$entry = htmlentities($_POST['entry']);
$utc_dttm = gmdate("Y-m-d H:i:s",time()+date("Z"));
$timestamp = strtotime($utc_dttm) - (420*60);
$cur_dttm = date("Y-m-d H:i:s", $timestamp);

$stmt = $handler->prepare('INSERT INTO jtest (cur_dttm, utc_dttm, entry) VALUES (:cur_dttm, :utc_dttm, :entry);');
//$stmt = $handler->prepare('INSERT INTO jtest (cur_dttm,utc_dttm,entry) VALUES (date_add($utc_dttm,interval -7 hour),utc_timestamp(),:entry)');

$stmt->bindValue(':cur_dttm', $cur_dttm);
$stmt->bindValue(':utc_dttm', $utc_dttm);
$stmt->bindValue(':entry', $entry);

/*
http://stackoverflow.com/questions/7908042/pdo-bindparam-timestamp-is-not-inserted
$insertSQL = 'INSERT INTO ds_session (session_id, user_agent, session_expire,
                    date_created, session_data)
            VALUES (:SESSION_ID, :USER_AGENT, FROM_UNIXTIME(:SESSION_EXPIRE),
                    FROM_UNIXTIME(:DATE_CREATED), :SESSION_DATA)';
*/

?>